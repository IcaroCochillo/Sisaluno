from django.db import models
from django.contrib.auth.models import AbstractUser, Group, Permission
from django.utils.translation import gettext_lazy as _

class Usuario(AbstractUser):
    
    TURMA_CHOICES = [
        ('1AI', '1AI'), ('1BI', '1BI'), ('1BA', '1BA'), ('1AA', '1AA'), ('1AB', '1AB'),
        ('2AI', '2AI'), ('2BI', '2BI'), ('2BA', '2BA'), ('2AA', '2AA'), ('2AB', '2AB'),
        ('3AI', '3AI'), ('3BI', '3BI'), ('3BA', '3BA'), ('3AA', '3AA'), ('3AB', '3AB'),
    ]
    username = models.CharField(max_length=255, unique=True)
    nome = models.CharField(max_length=255)
    idade = models.IntegerField()
    turma = models.CharField(max_length=4, choices=TURMA_CHOICES)
    is_lider = models.BooleanField(default=False)

    def __str__(self):
        return self.username

    groups = models.ManyToManyField(
        Group,
        verbose_name=_('groups'),
        blank=True,
        related_name='usuarios',  # Adicione um related_name único aqui
        help_text=_(
            'The groups this user belongs to. A user will get all permissions '
            'granted to each of their groups.'
        ),
    )

    user_permissions = models.ManyToManyField(
        Permission,
        verbose_name=_('user permissions'),
        blank=True,
        related_name='usuarios',  # Adicione um related_name único aqui
        help_text=_('Specific permissions for this user.'),
        error_messages={
            'add': _(
                'Cannot add user permission %(permission)s, because the user has the group '
                'permission %(perm)s.'
            ),
            'remove': _(
                'Cannot remove user permission %(permission)s, because the user has the group '
                'permission %(perm)s.'
            ),
        },
    )
