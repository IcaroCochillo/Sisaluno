from django.urls import path
from .views import list_usuarios, create_usuario, update_usuario, delete_usuario

urlpatterns =[
    path('', list_usuarios, name='list_usuarios'),
    path('new', create_usuario, name='create_usuarios'),
    path('update/<int:id>/', update_usuario, name='update_usuario'),
    path('delete/<int:id>/', delete_usuario, name='delete_usuario'),

]