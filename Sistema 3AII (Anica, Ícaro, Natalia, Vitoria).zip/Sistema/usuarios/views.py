from django.shortcuts import render, redirect
from .models import Usuario
from .forms import UsuarioForm
from django.core.exceptions import ValidationError
from django.contrib import messages

def list_usuarios(request):
    usuarios = Usuario.objects.all()
    return render(request, 'usuarios.html', {'usuarios': usuarios})

def create_usuario(request):
    form = UsuarioForm(request.POST or None)

    if form.is_valid():
        form.save()
        return redirect('list_usuarios')
    
    return render(request, 'usuarios-form.html', {'form': form})

def clean(self):

    if Usuario.objects.exclude(id=self.id).filter(username=self.username).exists():
        raise ValidationError({'username': 'Nome de usuário já está em uso.'})

def update_usuario(request, id):
    usuario = Usuario.objects.get(id=id)
    form = UsuarioForm(request.POST or None, instance=usuario)

    if form.is_valid():
        form.save()
        return redirect('list_usuarios')

    return render(request, 'usuarios-form.html', {'form': form, 'usuario': usuario})

def delete_usuario(request, id):
    usuario = Usuario.objects.get(id=id)

    if request.method == 'POST':
        usuario.delete()
        return redirect('list_usuarios')

    return render(request, 'user-delete-confirm.html', {'usuario': usuario})

